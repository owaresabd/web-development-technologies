/*----------------------------------------------------*/
/* Responsive Lightbox Build
/*----------------------------------------------------*/

	// create the galleries
	imagebox.creategallery('gallery', '');
	imagebox.creategallery('gallery2', '');
	imagebox.creategallery('gallery3', '');
	imagebox.creategallery('gallery4', '');
	imagebox.creategallery('gallery5', '');

			
	// build imagebox
	imagebox.build({
		// global options go here, these will affect all images
	});